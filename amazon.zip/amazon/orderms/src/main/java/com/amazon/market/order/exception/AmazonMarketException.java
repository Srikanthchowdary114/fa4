package com.amazon.market.order.exception;

public class AmazonMarketException extends Exception {

	private static final long serialVersionUID = 1L;

	public AmazonMarketException(String message) {
		super(message);
	}

}
